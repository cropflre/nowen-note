# QA body ^blk_069ae46c-fdd2-4ac8-8837-cb0e1e6c8e75
[fixture](/api/attachments/qa-file) ^blk_95e3751c-07eb-4c83-ac13-567a21316033