const DEFAULTS = {
  serverUrl: "",
  username: "",
  token: "",
  displayName: "",
  defaultNotebook: "Web 剪藏",
  defaultTags: "",
  imageMode: "inline",
  includeSource: true,
  outputFormat: "markdown",
  quickCapture: false,
  quickCaptureMode: "article",
  // AI 默认行为：默认关闭，主动开启；开启后默认做"摘要 + 标签"两项最稳的
  aiEnhanceEnabled: false,
  aiEnhanceTasks: {
    summary: true,
    tags: true,
    outline: false,
    title: false,
    highlight: false,
    translation: false
  },
  aiEnhanceMode: "prepend",
  aiEnhanceLanguage: "zh-CN",
  aiCustomInstruction: "",
  aiMaxInputChars: 6e3,
  aiFailureStrategy: "fallback"
};
const CONFIG_KEY = "nowenClipperConfig";
async function getConfig() {
  const store = chrome.storage.sync || chrome.storage.local;
  const data = await store.get(CONFIG_KEY);
  const raw = data[CONFIG_KEY] || {};
  const merged = { ...DEFAULTS, ...raw };
  if (raw.aiEnhanceTasks) {
    merged.aiEnhanceTasks = { ...DEFAULTS.aiEnhanceTasks, ...raw.aiEnhanceTasks };
  }
  return merged;
}
async function setConfig(patch) {
  const current = await getConfig();
  const merged = { ...current, ...patch };
  const store = chrome.storage.sync || chrome.storage.local;
  await store.set({ [CONFIG_KEY]: merged });
  return merged;
}
function isConfigured(cfg) {
  return !!cfg.serverUrl && !!cfg.token;
}
function normalizeBaseUrl(url) {
  return url.trim().replace(/\/+$/, "");
}
export {
  getConfig as g,
  isConfigured as i,
  normalizeBaseUrl as n,
  setConfig as s
};
